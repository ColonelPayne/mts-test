export interface IMovie {
  id: number;
  name: string;
  isOnline: boolean;
}
